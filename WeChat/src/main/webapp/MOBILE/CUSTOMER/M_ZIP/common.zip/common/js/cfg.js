try{
	window._RpcDefaultBaseURL='http://es.lianlife.com/WXIMG';
}catch(e)
{
}
;
try{
	window._LoginURL='http://login2.lianlife.com/LOGIN2';
}catch(e)
{
};
try{
	window._DEVICE='APP';
}catch(e)
{
};




